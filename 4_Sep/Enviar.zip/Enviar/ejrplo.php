<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Documento sin título</title>
</head>

<body>
<form id="form1" name="form1" method="get" action="valida.php">
  <p>
    <input type="checkbox" name="comida1" id="checkbox" value"pizza"/>
  Pizza</p>
  <p>
    <input type="checkbox" name="comida2" id="checkbox2" value"macarrones" /> 
  Macarrones</p>
  <p>
    <input type="checkbox" name="comida3" id="checkbox3"  value"hamburguesa"/>
    <label for="checkbox3"></label>
    <label for="checkbox2"></label>
    <label for="checkbox"></label>
  Hamburguesa ...:)</p>
  <p>&nbsp;</p>
  <p>
    <input type="submit" name="button" id="button" value="Enviar" />
  </p>
</form>
</body>
</html>