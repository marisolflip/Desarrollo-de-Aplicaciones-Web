<?php

$generos=$_GET["genero"];
if(isset($_GET['enviar'])){
echo $generos;

}else

header('location:botsuno.php');
exit;










?>