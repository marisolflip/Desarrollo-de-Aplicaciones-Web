<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Documento sin título</title>
</head>

<body>
<form id="form1" name="form1" method="get" action="validaradio.php">
  <p>
    <input type="radio" name="carrera"  value="sistemas" />
  Sistemas</p>
  <p>
    <input type="radio" name="carrera"  value="informatica" />
    <label for="radio2"></label>
  <label for="radio"></label>
  Informatica</p>
  <p>
    <input type="submit" name="enviar" id="button" value="Enviar" />
  </p>
</form>
</body>
</html>