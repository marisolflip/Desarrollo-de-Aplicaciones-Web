<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Documento sin título</title>
</head>

<body>
<form id="form1" name="form1" method="get" action="validaselect.php">
  <p>
    <label for="select"></label>
    <select name="ciudad" id="select">
    <option  value="SALTILLO">  Saltillo </option>
    <option  value="MONTERRYE"> Monterrey </option>
    <option  value="GUADALAJARA" selected="selected"> Guadalajara </option>
    <option  value"PUEBLA"> Puebla </option>
    
    
    
    
    
    
    </select>
  </p>
  <p>
    <input type="submit" name="enviar" id="button" value="Enviar" />
  </p>
</form>
</body>
</html>